﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 田代砲
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SHDocVw.InternetExplorer objIE = new SHDocVw.InternetExplorer(); //オブジェクトを作成
                webBrowser1.Refresh();  //再読み込み

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
